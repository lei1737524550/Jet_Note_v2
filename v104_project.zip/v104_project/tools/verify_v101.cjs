const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const assets = path.resolve(__dirname, '../app/src/main/assets');
(async () => {
  const attributes = {};
  const button = {setAttribute:(k,v)=>attributes[k]=v};
  const richHtml = '<span style="color:#ff0000"><b>红色 long text</b></span><u>other</u>';
  const text = {dataset:{}, style:{}, scrollHeight:260, innerHTML:richHtml, textContent:'红色 long text other'};
  const drawer = {dataset:{},style:{},getBoundingClientRect:()=>({height:156,width:320}),querySelector:()=>text};
  const article = {dataset:{postId:'1'},querySelector:selector=>selector==='.post-text-toggle'?button:drawer};
  text.closest=()=>article;
  const expanded = new Set();
  const context = vm.createContext({window:{__jetRuntimeConfig:{post_text_drawer_animation:{duration_ms:0}},addEventListener(){}},
    document:{querySelector:()=>article},CSS:{escape:s=>s},expandedPostIds:expanded,COLLAPSED_POST_LINE_LIMIT:6,
    getComputedStyle:()=>({lineHeight:'26px'}),requestAnimationFrame:fn=>fn(),t:s=>s,setTimeout,clearTimeout});
  vm.runInContext(fs.readFileSync(path.join(assets,'src/features/home/main_notes_renderer.js'),'utf8'),context);
  context.applyCollapsedPostText(text);
  assert.equal(text.style.maxHeight,'156px'); assert.equal(button.hidden,false);
  assert.equal(text.innerHTML,richHtml); assert.equal(attributes['aria-expanded'],'false');
  await context.togglePublishedPostText('1');
  assert.equal(text.style.maxHeight,''); assert.equal(text.innerHTML,richHtml); assert.equal(attributes['aria-expanded'],'true');
  await context.togglePublishedPostText('1');
  assert.equal(text.style.maxHeight,'156px'); assert.equal(text.innerHTML,richHtml);
  text.scrollHeight=52; context.applyCollapsedPostText(text);
  assert.equal(button.hidden,true); assert.equal(text.style.maxHeight,'');
  text.scrollHeight=260; context.applyCollapsedPostText(text);
  assert.equal(button.hidden,false); assert.equal(text.innerHTML,richHtml);

  const mediaSource=fs.readFileSync(path.join(assets,'src/features/home/note_video_image/note_video_image.js'),'utf8');
  const fitSource=mediaSource.slice(mediaSource.indexOf('function mediaObjectFit('));
  const listeners={};
  const mediaContext=vm.createContext({window:{},document:{documentElement:{},addEventListener:(k,v)=>listeners[k]=v},
    ResizeObserver:class{observe(){} unobserve(){}},MutationObserver:class{observe(){}},HTMLImageElement:class{}});
  vm.runInContext(fitSource,mediaContext);
  for(const count of [1,2,3]) {
    const img=vm.runInContext('new HTMLImageElement()',mediaContext);
    const styles={};let portrait=false;
    Object.assign(img,{naturalWidth:100,naturalHeight:600,clientWidth:200,clientHeight:200,
      matches:()=>true,closest:()=>({dataset:{mediaCount:String(count)}}),style:{setProperty:(k,v)=>styles[k]=v},
      parentElement:{classList:{toggle:(k,v)=>portrait=v}}});
    listeners.load({target:img});
    assert.equal(styles['--media-object-fit'],'scale-down');
    assert.equal(styles['--media-object-position'],'left center');assert.equal(portrait,true);
    img.naturalWidth=600;img.naturalHeight=100;listeners.load({target:img});
    assert.equal(styles['--media-object-position'],'center');assert.equal(portrait,false);
  }
  console.log('PASS: rich text survives collapse/expand/resize; overflow arrow; portrait fit in 1/2/3 slots');
})().catch(e=>{console.error(e);process.exit(1)});
