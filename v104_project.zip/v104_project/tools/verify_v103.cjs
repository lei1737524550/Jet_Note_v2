const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const assets=path.resolve(__dirname,'../app/src/main/assets');
class Element {
 constructor(){this.listeners={};this.values={};this.classes=new Set();this.classList={contains:k=>this.classes.has(k),toggle:(k,v)=>v?this.classes.add(k):this.classes.delete(k),remove:k=>this.classes.delete(k)};this.style={setProperty:(k,v)=>this.values[k]=v};this.scrollTop=0;this.scrollHeight=2000;this.clientHeight=600;this.offsetHeight=40;this.hidden=true;}
 addEventListener(k,fn){this.listeners[k]=fn;}
 querySelector(s){return this.children?.[s]||null;}
 cloneNode(){return makeBar();} removeAttribute(){}
 appendChild(bar){this.bar=bar;}
 setPointerCapture(id){this.capture=id;} hasPointerCapture(id){return this.capture===id;} releasePointerCapture(){this.capture=null;}
 getBoundingClientRect(){return {top:0,height:800};}
}
function makeBar(){const bar=new Element();bar.children={'.jet-scrollbar-track':new Element(),'.jet-scrollbar-thumb':new Element()};return bar;}
(async()=>{
 const home=new Element(),template=makeBar(),pages={};
 for(const [id,target] of [['settingsScreen','.settings-body'],['postComposeScreen','.post-compose-body'],['noteViewerScreen','#noteViewerScroll'],['archiveScreen','.archive-scroll']]){
  const page=new Element();page.children={[target]:new Element(),'.page-action-bar':new Element()};pages[id]=page;
 }
 let modal=false;const raf=[];
 const doc={scrollingElement:home,documentElement:home,body:new Element(),hidden:false,getElementById:id=>id==='jetScrollbar'?template:pages[id],querySelector:selector=>selector.includes('#imageViewer')&&modal?{}:null,addEventListener(){}};
 const window={innerHeight:900,addEventListener(){},visualViewport:{height:900,offsetTop:0,addEventListener(){}}};
 const context=vm.createContext({document:doc,window,requestAnimationFrame:fn=>raf.push(fn),ResizeObserver:class{observe(){}},MutationObserver:class{observe(){}},getComputedStyle:()=>({getPropertyValue:k=>({'--safe-top':'24px','--content-bottom':'30px','--page-action-bar-height':'40px'}[k]||'')}),fetch:async()=>({ok:true,json:async()=>({jet_scrollbar:{visual_width_px:7,interaction_width_px:20}})})});
 vm.runInContext(fs.readFileSync(path.join(assets,'src/shared/ui/scrollbar/jet_scrollbar.js'),'utf8'),context);
 await new Promise(resolve=>setImmediate(resolve));while(raf.length)raf.shift()();
 assert.equal(home.values['--jet-scrollbar-visual-width'],'3.5px');assert.equal(template.hidden,false);home.scrollTop=700;
 const refresh=window.JetNoteScrollbar.refresh;
 for(const [id,selector] of [['settingsScreen','.settings-body'],['postComposeScreen','.post-compose-body'],['noteViewerScreen','#noteViewerScroll'],['archiveScreen','.archive-scroll']]){
  const page=pages[id];page.classes.add('open');refresh();assert.equal(template.hidden,true);assert.equal(page.bar.hidden,false);
  const target=page.children[selector];target.scrollTop=target.scrollHeight-target.clientHeight;refresh();
  const thumb=page.bar.querySelector('.jet-scrollbar-thumb');assert.equal(page.bar.style.top,'64px');assert.equal(page.bar.style.height,'806px');
  const length=parseFloat(thumb.style.height);assert.equal(thumb.style.transform,`translateY(${806-length}px)`);
  target.scrollHeight=target.clientHeight;refresh();assert.equal(page.bar.hidden,true);target.scrollHeight=2000;
  page.classes.delete('open');refresh();assert.equal(page.bar.hidden,true);assert.equal(home.scrollTop,700);
 }
 // Switching routes during a captured drag must cancel ownership before more motion.
 template.listeners.pointerdown({pointerId:1,clientY:300,preventDefault(){},stopPropagation(){}});
 const before=home.scrollTop;pages.archiveScreen.classes.add('open');refresh();
 template.listeners.pointermove({pointerId:1,clientY:800,preventDefault(){},stopPropagation(){}});assert.equal(home.scrollTop,before);assert.equal(template.capture,null);
 modal=true;refresh();assert.ok([template,...Object.values(pages).map(p=>p.bar)].every(b=>b.hidden));
 console.log('PASS: five independent route scrollbars; exact endpoints; half width; overflow hiding; modal isolation; mid-drag switch');
 // Execute the production export preparation + callbacks without UI/Android transport.
 const notices=[],calls=[];const backupWindow={};const backup={window:backupWindow,structuredClone,Blob,localStorage:{getItem:()=>null},HOME_COMPOSER_LABEL_KEY:'label',EntryStore:{read:async()=>({posts:[]})},JetNoteNative:{exportJetNote:s=>calls.push(JSON.parse(s))},alert:s=>notices.push(s),t:s=>s};backupWindow.JetNoteNative=backup.JetNoteNative;
 vm.createContext(backup);vm.runInContext(fs.readFileSync(path.join(assets,'src/features/settings/backup_and_color.js'),'utf8')+'\nwindow.testBackup=JetNoteBackup;',backup);
 await backupWindow.testBackup.export();assert.equal(calls.length,1);assert.equal(notices.length,0);
 backupWindow.JetNoteBackupNative.onExportFinished(true,null);backupWindow.JetNoteBackupNative.onExportFinished(false,'INTERNAL SECRET');assert.deepEqual(notices,['exportDone','exportFailed']);
 backup.EntryStore.read=async()=>{throw Error('database failure');};await backupWindow.testBackup.export();assert.equal(notices.at(-1),'exportFailed');
 const native=fs.readFileSync(path.resolve(__dirname,'../app/src/main/kotlin/com/leixj/jetnote/BackupFileController.kt'),'utf8');
 assert.match(native,/onCancelled/);
 assert.match(native,/if\(code==SAVE\)pendingExport=null/);
 console.log('PASS: export success waits for final callback; sanitized failure; preparation failure; silent SAF cancellation branch');
})().catch(e=>{console.error(e);process.exit(1)});
