Jet Note 后续工作规则（自v102建立）

1. 先读docs/readme.txt、architecture.txt和codebase.txt，再读本轮问题目录全部.txt及对应截图。
2. 旧issues中的readme_before_work.txt是当时的原始输入，保留用于追溯。当前用户明确要求优先于本文件；历史批次要求仅用于该批次。
3. 按issues/issue_severity_rating_criteria.txt优先处理高星级问题；存在根因依赖时先处理根因。v100问题3应先于问题2。
4. 保留issue原文、截图和目录名，新增同目录resolution_v版本_序号.txt；不要把原问题改写成修复说明。
5. 修复记录必须写Root Cause、Solution、Modified Files、Verification、Notes和状态，明确未编译、未渲染或未真机测试。
6. 长期取舍新增decisions/decision_v版本_序号.txt；不要用另一套ISSUE-001/ADR-001编号。
7. 修改职责或数据协议时更新architecture/codebase，并检查文档引用的源文件确实存在。
8. 交付完整项目，保留docs，压缩包按当前交付v数字加1命名；不要把Gradle缓存或编译产物当作源代码打包。
9. 不擅自删除功能或改变平台架构。文档整理本身无需重构app代码。
