Jet Note 工程文档入口
文档对应交付版本：v104；应用代码包含截至v104的整改。
版本标签v100/v101/v102是交付包编号，并非Android versionCode/versionName。
本轮整改创作图标线宽、归档卡片/收藏、导入导出进度及启动重复显示，Gradle配置保持原值。

阅读顺序
1. readme_before_work.txt：后续维护约定。
2. architecture.txt：真实架构、数据流、职责边界。
3. codebase.txt：按功能定位源文件与验证入口。
4. decisions/：重要方案为何这样选择。
5. issues/：各版本的问题原文、截图和独立修复记录。

目录约定
app/与docs/处于项目根目录的同一层。
源码文件路径均相对项目根目录；文档间路径均相对docs/。
issues/v100/保留用户原始v100_issue目录内容和命名；不得改写原问题文件或截图。
同一问题的记录保存在其原目录内：issue_v100_1.txt配resolution_v100_1.txt。
🌟目录名称完全保留原评级；修复后也不重命名。
问题编号采用发现问题时的版本，修复版本写进resolution，不搬到新版本目录。
例如：v100提出、v101修复的问题仍留在issues/v100/。
新问题才放issues/v102/或之后的版本，不为没有问题的版本编造issue。
issues/issue_severity_rating_criteria.txt是当前共享评级说明；各旧版本副本是历史原文。
issues/v100/v101_changes.txt保留上一轮总修复说明，逐项记录以resolution文件为准。
issues/v102/readme.txt记录本轮文档整理和验证范围。

修复记录统一字段
Status: 已修改 / 静态检查通过 / 行为测试通过 / 真机确认 / 未解决；可组合。
Reported Version: 问题提出版本。
Implemented Version: 代码修改版本；没有修改则填无。
Root Cause: 代码依据和根因；推断需注明。
Solution: 最终方案及关键取舍。
Modified Files: 相对项目根目录的实际修改路径。
Verification: 实际执行的检查、结果、未执行项目。
Notes: 关联问题、限制、回归步骤和后来确认的结果。
不要只写“已解决”；记录验证证据。后续验证追加日期、版本和结果，不覆盖历史结论。

决策记录统一字段
Context / Decision / Alternatives / Consequences / Verification / Related Issues。
decision_v版本_序号.txt采用做出决策时的版本号；历史补录必须明确注明。
文件只解释重要长期取舍，不给每一行代码建立文档。

后续维护
涉及模块职责、数据格式、导出路径、文件入口或运行平台变化时，同步更新architecture/codebase。
一个问题一份resolution；同根因的多个问题互相引用，保留各自原始描述。
图片/视频/音频、网页/原生的现状以当前源码为准，不把未来迁移目标当作已实现。

当前整改记录：issues/v103/v104_changes.txt；四项原文、截图及resolution分别存于issues/v103/1至4。
