package com.leixj.jetnote;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.HapticFeedbackConstants;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.FrameLayout;

import org.json.JSONObject;

import java.io.File;

/**
 * Inline Android-native video renderer for Jet Note.
 *
 * The WebView owns the post card/progress UI. Android owns only the decoded
 * video surface and MediaPlayer state. The native surface is positioned over
 * the exact video-card rectangle reported by JavaScript, so playback stays
 * inline instead of opening a fullscreen overlay.
 */
final class NativeVideoPlayer implements TextureView.SurfaceTextureListener {
    private final Activity activity;
    private final FrameLayout root;
    private final WebView webView;
    private final AttachmentStore store;

    private FrameLayout stage;
    private TextureView textureView;
    private MediaPlayer player;
    private Surface surface;
    private File currentFile;
    private String mediaId;

    private int durationMs;
    private boolean prepared;
    private boolean everStarted;
    private boolean userSeeking;
    private boolean wasPlayingBeforeSeek;
    private boolean autoStartWhenPrepared;
    private double pendingSeekFraction = -1d;
    private boolean pendingSeekShouldPlay;
    private boolean overlayAllowed = true;
    private int playerGeneration = 0;

    // Keep the native TextureView locked to the WebView during scrolling.
    // JS still reports the authoritative DOM rectangle, but a JS -> bridge -> UI-thread
    // round trip can trail the WebView compositor by one or two frames.  Remember the
    // last authoritative position and apply the WebView scroll delta natively so the
    // video surface moves in the same frame as its HTML card.
    private float rectAnchorX;
    private float rectAnchorY;
    private int rectAnchorScrollX;
    private int rectAnchorScrollY;
    private boolean hasRectAnchor;
    // The native video stage is a rounded Android sibling above WebView. Once it
    // has rendered even one frame it remains alive while paused, which is why the
    // reported "rounded shaking box" appears after a video has merely been loaded.
    // Never try to chase WebView scrolling with that sibling. Hide only its pixels
    // while WebView is moving, then re-anchor from a fresh DOM rect when scrolling
    // settles. The HTML poster underneath stays phase-locked with WebView.
    private boolean renderingStarted;
    private boolean scrollReanchorPending;
    private boolean scrollFrameCaptured;
    private String scrollCaptureToken = "";
    private final Runnable scrollSettleReanchor;

    private int videoWidth;
    private int videoHeight;
    private float zoom = 1f;

    private float downX;
    private float downY;
    private float lastRawY;
    private boolean scrollingGesture;
    private final int touchSlop;
    private ScaleGestureDetector scaleDetector;
    private boolean scaleGestureOccurred;
    private float rightEdgeGestureYieldPercent = 7f;

    // Same deliberate long-press reset contract as the proven Video Lab player.
    // The reset itself happens on ACTION_UP after the hold threshold has fired.
    private static final long LONG_PRESS_MS = 550L;
    private boolean longPressReady;
    private Runnable longPressRunnable;

    private final Runnable progressTicker = new Runnable() {
        @Override public void run() {
            if (!isOpen()) return;
            dispatchProgress();
            if (stage != null) stage.postDelayed(this, 100L);
        }
    };

    NativeVideoPlayer(Activity activity, FrameLayout root, WebView webView, AttachmentStore store) {
        this.activity = activity;
        this.root = root;
        this.webView = webView;
        this.store = store;
        // Initialize after webView is assigned. A field-initializer lambda that reads
        // the final webView field is rejected by javac as potentially uninitialized.
        this.scrollSettleReanchor = () -> {
            if (!isOpen()) return;
            scrollReanchorPending = true;
            scrollFrameCaptured = false;
            this.webView.evaluateJavascript(
                    "window.__jetRefreshNativeVideoRect&&window.__jetRefreshNativeVideoRect();",
                    null);
        };
        this.touchSlop = ViewConfiguration.get(activity).getScaledTouchSlop();
        webView.getViewTreeObserver().addOnScrollChangedListener(this::onWebViewScrolled);
    }

    private void onWebViewScrolled() {
        if (stage == null) return;
        // getBoundingClientRect() is already viewport-relative. Moving the native
        // stage from WebView.getScrollY() as well created a second, asynchronous
        // scroll path (WebView compositor vs Android sibling), producing the jitter.
        // Alpha=0 keeps touch ownership intact if the gesture began on the video.
        if (!scrollFrameCaptured) {
            scrollFrameCaptured = true;
            scrollCaptureToken = "scroll:" + playerGeneration + ":" + System.nanoTime();
            captureVideoFrame(scrollCaptureToken);
        }
        stage.animate().cancel();
        scrollReanchorPending = false;
        webView.removeCallbacks(scrollSettleReanchor);
        webView.postDelayed(scrollSettleReanchor, 96L);
    }


    /** Capture the rendered TextureView, including cover/zoom, on the UI thread.
     * The bounded bitmap lives only in memory; no media files are written. */
    void captureVideoFrame(String token) {
        activity.runOnUiThread(() -> {
            String id = mediaId == null ? "" : mediaId;
            String data = "";
            Bitmap raw = null;
            Bitmap frame = null;
            try {
                if (textureView != null && textureView.isAvailable() && renderingStarted
                        && textureView.getWidth() > 0 && textureView.getHeight() > 0) {
                    int vw = textureView.getWidth(), vh = textureView.getHeight();
                    float ratio = Math.min(1f, 720f / Math.max(vw, vh));
                    int w = Math.max(1, Math.round(vw * ratio));
                    int h = Math.max(1, Math.round(vh * ratio));
                    raw = textureView.getBitmap(w, h);
                    if (raw != null) {
                        frame = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                        Canvas canvas = new Canvas(frame);
                        canvas.drawColor(Color.BLACK);
                        canvas.translate(textureView.getTranslationX() * ratio, textureView.getTranslationY() * ratio);
                        canvas.scale(textureView.getScaleX(), textureView.getScaleY(),
                                textureView.getPivotX() * ratio, textureView.getPivotY() * ratio);
                        canvas.drawBitmap(raw, 0f, 0f, null);
                        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                        frame.compress(Bitmap.CompressFormat.JPEG, 85, bytes);
                        data = "data:image/jpeg;base64," + Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP);
                    }
                }
            } catch (RuntimeException ignored) {
                // JS retains its previous frame if the surface is unavailable.
            } finally {
                if (raw != null) raw.recycle();
                if (frame != null) frame.recycle();
            }
            webView.evaluateJavascript("window.__jetReceiveVideoFrame&&window.__jetReceiveVideoFrame("
                    + JSONObject.quote(token == null ? "" : token) + "," + JSONObject.quote(id)
                    + "," + JSONObject.quote(data) + ")", null);
        });
    }

    void confirmScrollVideoFrame(String token) {
        activity.runOnUiThread(() -> {
            if (stage != null && scrollFrameCaptured && scrollCaptureToken.equals(token)) {
                stage.setAlpha(0f);
            }
        });
    }

    void setRightEdgeGestureYieldPercent(double percent) {
        activity.runOnUiThread(() -> {
            float value = (float) percent;
            if (!Float.isFinite(value)) value = 7f;
            rightEdgeGestureYieldPercent = Math.max(0f, Math.min(40f, value));
        });
    }

    boolean isOpen() {
        return stage != null && stage.getParent() != null;
    }

    void setOverlayAllowed(boolean allowed) {
        activity.runOnUiThread(() -> {
            if (!allowed && overlayAllowed) captureVideoFrame("");
            overlayAllowed = allowed;
            if (stage == null) return;
            if (!allowed) {
                try {
                    if (prepared && player != null && player.isPlaying()) player.pause();
                } catch (RuntimeException ignored) { }
                stage.setVisibility(View.INVISIBLE);
                dispatchProgress();
            } else {
                stage.setVisibility(View.VISIBLE);
                dispatchProgress();
            }
        });
    }

    void playInline(
            String archivePath,
            String requestedMediaId,
            double leftCss,
            double topCss,
            double widthCss,
            double heightCss,
            double devicePixelRatio
    ) {
        activity.runOnUiThread(() -> {
            if (!overlayAllowed) return;
            File file = store.fileForArchivePath(archivePath);
            if (file == null || !file.isFile()) return;

            if (isOpen() && requestedMediaId != null && requestedMediaId.equals(mediaId)
                    && currentFile != null && currentFile.equals(file)) {
                updateRectInternal(leftCss, topCss, widthCss, heightCss, devicePixelRatio);
                togglePlayback();
                return;
            }

            closeInternal(false);
            currentFile = file;
            mediaId = requestedMediaId == null ? "" : requestedMediaId;
            durationMs = 0;
            prepared = false;
            everStarted = false;
            userSeeking = false;
            wasPlayingBeforeSeek = false;
            autoStartWhenPrepared = true;
            pendingSeekFraction = -1d;
            pendingSeekShouldPlay = false;
            videoWidth = 0;
            videoHeight = 0;
            zoom = 1f;
            scaleGestureOccurred = false;
            renderingStarted = false;
            scrollReanchorPending = false;

            createInlineStage();
            updateRectInternal(leftCss, topCss, widthCss, heightCss, devicePixelRatio);
            stage.post(progressTicker);

            if (textureView.isAvailable()) {
                onSurfaceTextureAvailable(
                        textureView.getSurfaceTexture(),
                        textureView.getWidth(),
                        textureView.getHeight());
            }
        });
    }

    void updateRect(
            String requestedMediaId,
            double leftCss,
            double topCss,
            double widthCss,
            double heightCss,
            double devicePixelRatio
    ) {
        activity.runOnUiThread(() -> {
            if (!isOpen() || requestedMediaId == null || !requestedMediaId.equals(mediaId)) return;
            updateRectInternal(leftCss, topCss, widthCss, heightCss, devicePixelRatio);
        });
    }

    void beginSeek(String requestedMediaId, double fraction) {
        activity.runOnUiThread(() -> {
            if (!matches(requestedMediaId)) return;
            userSeeking = true;
            if (!prepared || player == null || durationMs <= 0) {
                pendingSeekFraction = clamp01(fraction);
                pendingSeekShouldPlay = true;
                return;
            }
            try {
                wasPlayingBeforeSeek = player.isPlaying();
            } catch (RuntimeException ignored) {
                wasPlayingBeforeSeek = false;
            }
        });
    }

    void endSeek(String requestedMediaId, double fraction) {
        activity.runOnUiThread(() -> {
            if (!matches(requestedMediaId)) return;
            if (!prepared || player == null || durationMs <= 0) {
                pendingSeekFraction = clamp01(fraction);
                pendingSeekShouldPlay = true;
                userSeeking = false;
                return;
            }

            int target = Math.max(0, Math.min(durationMs,
                    (int) Math.round(durationMs * clamp01(fraction))));
            try {
                player.seekTo(target);
                if (wasPlayingBeforeSeek) {
                    if (!player.isPlaying()) player.start();
                } else if (player.isPlaying()) {
                    player.pause();
                }
            } catch (RuntimeException ignored) { }
            userSeeking = false;
            dispatchProgress();
        });
    }

    void synchronizeViewerPosition(String requestedMediaId, int positionMs) {
        activity.runOnUiThread(() -> {
            if (!matches(requestedMediaId) || player == null || !prepared) return;
            try {
                int safePosition = Math.max(0, durationMs > 0
                        ? Math.min(positionMs, Math.max(0, durationMs - 1))
                        : positionMs);
                player.seekTo(safePosition);
                if (player.isPlaying()) player.pause();
                everStarted = true;
                dispatchProgress();
            } catch (RuntimeException ignored) { }
        });
    }

    void stop(String requestedMediaId) {
        activity.runOnUiThread(() -> {
            if (requestedMediaId == null || requestedMediaId.isEmpty() || matches(requestedMediaId)) {
                closeInternal(true);
            }
        });
    }

    void onHostPause() {
        activity.runOnUiThread(() -> {
            if (player != null && prepared) {
                try {
                    if (player.isPlaying()) player.pause();
                } catch (RuntimeException ignored) { }
                dispatchProgress();
            }
        });
    }

    void onHostResume() {
        activity.runOnUiThread(() -> {
            if (isOpen() && stage != null) {
                stage.removeCallbacks(progressTicker);
                stage.post(progressTicker);
            }
        });
    }

    void close() {
        activity.runOnUiThread(() -> closeInternal(true));
    }

    private boolean matches(String requestedMediaId) {
        return requestedMediaId != null && requestedMediaId.equals(mediaId) && isOpen();
    }

    private void cancelLongPressTimer() {
        if (stage != null && longPressRunnable != null) stage.removeCallbacks(longPressRunnable);
        longPressRunnable = null;
    }

    private void armLongPressReset() {
        cancelLongPressTimer();
        longPressReady = false;
        if (stage == null) return;
        longPressRunnable = () -> {
            longPressRunnable = null;
            longPressReady = true;
            try { stage.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); } catch (RuntimeException ignored) { }
        };
        stage.postDelayed(longPressRunnable, LONG_PRESS_MS);
    }

    /**
     * True cold reset. Do not seek the existing decoder back to zero: retire the
     * whole MediaPlayer + Surface + TextureView pipeline so no old decoded frame
     * can survive and flash on the next play. The WebView poster underneath is
     * already Jet Note's extracted real first frame.
     */
    private void coldResetFromLongPress() {
        String resetMediaId = mediaId;
        cancelLongPressTimer();
        longPressReady = false;
        closeInternal(false);
        dispatchReset(resetMediaId);
    }

    private void createInlineStage() {
        stage = new FrameLayout(activity);
        GradientDrawable stageBackground = new GradientDrawable();
        stageBackground.setColor(Color.BLACK);
        stageBackground.setCornerRadius(dp(14));
        stage.setBackground(stageBackground);
        stage.setClipChildren(true);
        stage.setClipToOutline(true);
        stage.setAlpha(0f); // keep the real first-frame poster visible until native rendering starts
        stage.setVisibility(overlayAllowed ? View.VISIBLE : View.INVISIBLE);

        textureView = new TextureView(activity);
        textureView.setOpaque(true);
        textureView.setSurfaceTextureListener(this);
        stage.addView(textureView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        scaleDetector = new ScaleGestureDetector(activity,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    @Override public boolean onScaleBegin(ScaleGestureDetector detector) {
                        scaleGestureOccurred = true;
                        updateVideoTransformPivot(detector.getFocusX(), detector.getFocusY());
                        return true;
                    }

                    @Override public boolean onScale(ScaleGestureDetector detector) {
                        // Keep the zoom anchored to the midpoint between the two fingers.
                        // The previous implementation only changed scaleX/scaleY, so Android
                        // always enlarged the TextureView around its center regardless of
                        // where the gesture actually happened.
                        updateVideoTransformPivot(detector.getFocusX(), detector.getFocusY());
                        zoom *= detector.getScaleFactor();
                        zoom = Math.max(1f, Math.min(4f, zoom));
                        if (zoom <= 1.001f) resetVideoTransformPivot();
                        applyVideoTransform();
                        return true;
                    }
                });

        stage.setOnTouchListener((view, event) -> {
            scaleDetector.onTouchEvent(event);
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    // The configured right-most slice belongs to the WebView/right-edge scrollbar.
                    // Returning false on DOWN lets Android continue hit-testing the WebView below;
                    // that target then owns the complete gesture sequence.
                    if (stage.getWidth() > 0 && event.getX() >= stage.getWidth() * (1f - rightEdgeGestureYieldPercent / 100f)) {
                        return false;
                    }
                    scaleGestureOccurred = false;
                    downX = event.getX();
                    downY = event.getY();
                    lastRawY = event.getRawY();
                    scrollingGesture = false;
                    armLongPressReset();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    if (scaleDetector.isInProgress()) {
                        cancelLongPressTimer();
                        longPressReady = false;
                        return true;
                    }
                    float dx = event.getX() - downX;
                    float dy = event.getY() - downY;
                    if (Math.hypot(dx, dy) > touchSlop) {
                        cancelLongPressTimer();
                        longPressReady = false;
                    }
                    if (!scrollingGesture && Math.abs(dy) > touchSlop && Math.abs(dy) > Math.abs(dx)) {
                        scrollingGesture = true;
                    }
                    if (scrollingGesture) {
                        float rawY = event.getRawY();
                        int delta = Math.round(lastRawY - rawY);
                        lastRawY = rawY;
                        if (delta != 0) webView.scrollBy(0, delta);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    cancelLongPressTimer();
                    if (longPressReady) {
                        // Exactly like maine: recognition can happen while held,
                        // but destructive reset waits for the finger to lift.
                        coldResetFromLongPress();
                        return true;
                    }
                    longPressReady = false;
                    if (!scrollingGesture && !scaleGestureOccurred && !scaleDetector.isInProgress()) {
                        dispatchVideoSurfaceTapped();
                    }
                    scrollingGesture = false;
                    scaleGestureOccurred = false;
                    return true;

                case MotionEvent.ACTION_CANCEL:
                    cancelLongPressTimer();
                    longPressReady = false;
                    scrollingGesture = false;
                    scaleGestureOccurred = false;
                    return true;

                default:
                    return true;
            }
        });

        root.addView(stage, new FrameLayout.LayoutParams(1, 1));
        stage.setElevation(UiLayerHeights.MEDIA);
        stage.bringToFront();
    }

    private void updateRectInternal(
            double leftCss,
            double topCss,
            double widthCss,
            double heightCss,
            double devicePixelRatio
    ) {
        if (stage == null) return;

        float scale = (float) devicePixelRatio;
        if (!Float.isFinite(scale) || scale <= 0f) {
            scale = activity.getResources().getDisplayMetrics().density;
        }

        mediaPixelRatio = scale;
        int[] webLocation = new int[2];
        int[] rootLocation = new int[2];
        webView.getLocationOnScreen(webLocation);
        root.getLocationOnScreen(rootLocation);

        float x = webLocation[0] - rootLocation[0] + (float) leftCss * scale;
        float y = webLocation[1] - rootLocation[1] + (float) topCss * scale;
        int width = Math.max(1, Math.round((float) widthCss * scale));
        int height = Math.max(1, Math.round((float) heightCss * scale));

        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) stage.getLayoutParams();
        if (lp == null) lp = new FrameLayout.LayoutParams(width, height);
        lp.width = width;
        lp.height = height;
        stage.setLayoutParams(lp);
        stage.setX(x);
        stage.setY(y);
        rectAnchorX = x;
        rectAnchorY = y;
        rectAnchorScrollX = webView.getScrollX();
        rectAnchorScrollY = webView.getScrollY();
        hasRectAnchor = true;
        applyVideoTransform();
        if (scrollReanchorPending) {
            scrollReanchorPending = false;
            if (renderingStarted && overlayAllowed) {
                stage.animate().cancel();
                stage.setAlpha(1f);
            }
        }
    }

    private void createPlayer(Surface targetSurface) {
        releasePlayerOnly();
        if (currentFile == null || targetSurface == null || !targetSurface.isValid()) return;

        final int generation = ++playerGeneration;
        final MediaPlayer candidate = new MediaPlayer();
        player = candidate;
        candidate.setSurface(targetSurface);
        candidate.setOnPreparedListener(mp -> {
            if (generation != playerGeneration || player != mp || !isOpen()) return;
            prepared = true;
            durationMs = Math.max(0, mp.getDuration());
            if (pendingSeekFraction >= 0d && durationMs > 0) {
                int target = Math.max(0, Math.min(durationMs,
                        (int) Math.round(durationMs * clamp01(pendingSeekFraction))));
                try { mp.seekTo(target); } catch (RuntimeException ignored) { }
                boolean shouldPlay = pendingSeekShouldPlay;
                pendingSeekFraction = -1d;
                pendingSeekShouldPlay = false;
                autoStartWhenPrepared = false;
                if (shouldPlay && overlayAllowed) {
                    try {
                        everStarted = true;
                        mp.start();
                    } catch (RuntimeException ignored) { }
                }
            } else if (autoStartWhenPrepared) {
                autoStartWhenPrepared = false;
                if (overlayAllowed) {
                    try {
                        everStarted = true;
                        mp.start();
                    } catch (RuntimeException ignored) { }
                }
            }
            dispatchProgress();
        });
        candidate.setOnVideoSizeChangedListener((mp, width, height) -> {
            if (generation != playerGeneration || player != mp || !isOpen()) return;
            videoWidth = Math.max(0, width);
            videoHeight = Math.max(0, height);
            applyVideoTransform();
        });
        candidate.setOnInfoListener((mp, what, extra) -> {
            if (generation != playerGeneration || player != mp || !isOpen()) return true;
            if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START && stage != null) {
                renderingStarted = true;
                if (!scrollReanchorPending) {
                    stage.animate().alpha(1f).setDuration(80L).start();
                }
            }
            return false;
        });
        candidate.setOnCompletionListener(mp -> {
            if (generation != playerGeneration || player != mp || !isOpen()) return;
            dispatchProgress();
        });
        candidate.setOnSeekCompleteListener(mp -> {
            if (generation == playerGeneration && player == mp && isOpen()) dispatchProgress();
        });
        candidate.setOnErrorListener((mp, what, extra) -> {
            if (generation != playerGeneration || player != mp || !isOpen()) return true;
            prepared = false;
            if (stage != null) stage.setAlpha(0f); // fall back to HTML poster
            dispatchProgress();
            return true;
        });

        try {
            candidate.setDataSource(currentFile.getAbsolutePath());
            candidate.prepareAsync();
        } catch (Exception ignored) {
            prepared = false;
            if (stage != null) stage.setAlpha(0f);
            dispatchProgress();
        }
    }

    private void togglePlayback() {
        if (!prepared || player == null) return;
        try {
            if (player.isPlaying()) {
                player.pause();
            } else {
                if (durationMs > 0 && player.getCurrentPosition() >= durationMs - 100) {
                    player.seekTo(0);
                }
                everStarted = true;
                player.start();
            }
            dispatchProgress();
        } catch (RuntimeException ignored) { }
    }

    private void dispatchProgress() {
        if (!isOpen() || userSeeking || mediaId == null) return;

        int current = 0;
        boolean playing = false;
        if (prepared && player != null) {
            try {
                current = Math.max(0, player.getCurrentPosition());
                playing = player.isPlaying();
            } catch (RuntimeException ignored) { }
        }

        String script = "window.__jetNativeVideoProgress&&window.__jetNativeVideoProgress("
                + JSONObject.quote(mediaId) + ","
                + current + ","
                + Math.max(0, durationMs) + ","
                + (playing ? "true" : "false") + ","
                + (everStarted ? "true" : "false") + ");";
        webView.evaluateJavascript(script, null);
    }

    private void dispatchClosed(String closedMediaId) {
        if (closedMediaId == null || closedMediaId.isEmpty()) return;
        webView.evaluateJavascript(
                "window.__jetNativeVideoClosed&&window.__jetNativeVideoClosed("
                        + JSONObject.quote(closedMediaId) + ");",
                null);
    }

    private void dispatchReset(String resetMediaId) {
        if (resetMediaId == null || resetMediaId.isEmpty()) return;
        webView.evaluateJavascript(
                "window.__jetNativeVideoReset&&window.__jetNativeVideoReset("
                        + JSONObject.quote(resetMediaId) + ");",
                null);
    }

    /**
     * Move TextureView's transform pivot without visually jumping the already
     * zoomed frame. This lets consecutive pinch gestures start from a new
     * two-finger midpoint instead of snapping back to the view center.
     */
    private void updateVideoTransformPivot(float pivotX, float pivotY) {
        if (textureView == null) return;
        float oldPivotX = textureView.getPivotX();
        float oldPivotY = textureView.getPivotY();
        float sx = textureView.getScaleX();
        float sy = textureView.getScaleY();
        textureView.setTranslationX(textureView.getTranslationX()
                + (oldPivotX - pivotX) * (1f - sx));
        textureView.setTranslationY(textureView.getTranslationY()
                + (oldPivotY - pivotY) * (1f - sy));
        textureView.setPivotX(pivotX);
        textureView.setPivotY(pivotY);
    }

    private void resetVideoTransformPivot() {
        if (textureView == null) return;
        textureView.setPivotX(textureView.getWidth() / 2f);
        textureView.setPivotY(textureView.getHeight() / 2f);
        textureView.setTranslationX(0f);
        textureView.setTranslationY(0f);
    }

    private void dispatchVideoSurfaceTapped() {
        if (mediaId == null || mediaId.isEmpty()) return;
        int current = 0;
        if (prepared && player != null) {
            try { current = Math.max(0, player.getCurrentPosition()); }
            catch (RuntimeException ignored) { }
        }
        webView.evaluateJavascript(
                "window.__jetNativeVideoSurfaceTapped&&window.__jetNativeVideoSurfaceTapped("
                        + JSONObject.quote(mediaId) + "," + current + ");",
                null);
    }

    private boolean cropMedia = false;
    private float mediaPixelRatio = 1f;

    public void setCropMode(boolean crop) {
        activity.runOnUiThread(() -> {
            cropMedia = crop;
            applyVideoTransform();
        });
    }

    private void applyVideoTransform() {
        if (textureView == null) return;
        int viewWidth = textureView.getWidth();
        int viewHeight = textureView.getHeight();
        if (viewWidth <= 0 || viewHeight <= 0 || videoWidth <= 0 || videoHeight <= 0) {
            textureView.setScaleX(zoom);
            textureView.setScaleY(zoom);
            return;
        }

        // CSS uses source pixels as intrinsic CSS size. Convert that bound to
        // device pixels so poster and actual playback follow the same rule.
        float fitX = viewWidth / (float) videoWidth;
        float fitY = viewHeight / (float) videoHeight;
        float fit = cropMedia ? Math.max(fitX, fitY) : Math.min(fitX, fitY);
        fit = Math.min(mediaPixelRatio, fit);
        float sx = videoWidth * fit / viewWidth;
        float sy = videoHeight * fit / viewHeight;
        textureView.setScaleX(sx * zoom);
        textureView.setScaleY(sy * zoom);
    }

    private void closeInternal(boolean notifyFrontend) {
        String closedMediaId = mediaId;
        cancelLongPressTimer();
        longPressReady = false;
        if (stage != null) stage.removeCallbacks(progressTicker);
        releasePlayerOnly();
        if (surface != null) {
            try { surface.release(); } catch (RuntimeException ignored) { }
            surface = null;
        }
        if (stage != null && stage.getParent() instanceof ViewGroup) {
            ((ViewGroup) stage.getParent()).removeView(stage);
        }
        webView.removeCallbacks(scrollSettleReanchor);
        stage = null;
        hasRectAnchor = false;
        renderingStarted = false;
        scrollReanchorPending = false;
        scrollFrameCaptured = false;
        textureView = null;
        currentFile = null;
        mediaId = null;
        durationMs = 0;
        prepared = false;
        everStarted = false;
        userSeeking = false;
        autoStartWhenPrepared = false;
        videoWidth = 0;
        videoHeight = 0;
        zoom = 1f;
        scaleGestureOccurred = false;
        if (notifyFrontend) dispatchClosed(closedMediaId);
    }

    private void releasePlayerOnly() {
        playerGeneration++;
        prepared = false;
        if (player != null) {
            try { player.reset(); } catch (RuntimeException ignored) { }
            try { player.release(); } catch (RuntimeException ignored) { }
            player = null;
        }
    }

    @Override public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int width, int height) {
        if (surface != null) {
            try { surface.release(); } catch (RuntimeException ignored) { }
        }
        surface = new Surface(surfaceTexture);
        createPlayer(surface);
    }

    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int width, int height) {
        applyVideoTransform();
    }

    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        releasePlayerOnly();
        if (surface != null) {
            try { surface.release(); } catch (RuntimeException ignored) { }
            surface = null;
        }
        return true;
    }

    @Override public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) { }

    private int dp(int value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }

    private static double clamp01(double value) {
        return Math.max(0d, Math.min(1d, value));
    }
}
