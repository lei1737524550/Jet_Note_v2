package com.leixj.jetnote;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Insets;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.WebView;

/** Extends the surface behind system bars; forwards safe content edges to CSS. */
final class EdgeToEdgeController {
    private final Activity activity;
    private final WebView webView;
    private int safeTop, safeRight, safeBottom, safeLeft, keyboardViewportHeight, keyboardHeight;
    private boolean hasInsets;

    EdgeToEdgeController(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    @SuppressWarnings("deprecation")
    void install() {
        Window window = activity.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Build.VERSION.SDK_INT >= 26 ? Color.TRANSPARENT : 0x66000000);
        applySystemBarVisibility();
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams params = window.getAttributes();
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            window.setAttributes(params);
            window.setNavigationBarDividerColor(Color.TRANSPARENT);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            window.setStatusBarContrastEnforced(false);
            window.setNavigationBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false);
        webView.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                safeTop = bars.top; safeRight = bars.right; safeBottom = bars.bottom; safeLeft = bars.left;
                if (insets.isVisible(WindowInsets.Type.ime())) {
                    int imeBottom = insets.getInsets(WindowInsets.Type.ime()).bottom;
                    keyboardHeight = Math.max(0, imeBottom - safeBottom);
                    int windowHeight = activity.getWindowManager().getCurrentWindowMetrics().getBounds().height();
                    // This is the usable window height above the IME, not the IME height itself.
                    keyboardViewportHeight = Math.max(1, Math.min(webView.getHeight(), windowHeight - imeBottom));
                } else {
                    keyboardViewportHeight = 0;
                    keyboardHeight = 0;
                }
            } else {
                safeTop = insets.getSystemWindowInsetTop();
                safeRight = insets.getSystemWindowInsetRight();
                // Stable safeBottom excludes the keyboard on API 23–29.
                safeBottom = insets.getStableInsetBottom();
                keyboardHeight = 0; // visualViewport supplies the API 23-29 fallback.
                safeLeft = insets.getSystemWindowInsetLeft();
                if (Build.VERSION.SDK_INT >= 28 && insets.getDisplayCutout() != null) {
                    safeTop = Math.max(safeTop, insets.getDisplayCutout().getSafeInsetTop());
                    safeLeft = Math.max(safeLeft, insets.getDisplayCutout().getSafeInsetLeft());
                    safeRight = Math.max(safeRight, insets.getDisplayCutout().getSafeInsetRight());
                    safeBottom = Math.max(safeBottom, insets.getDisplayCutout().getSafeInsetBottom());
                }
            }
            hasInsets = true;
            dispatchInsets();
            return insets;
        });
        webView.requestApplyInsets();
    }

    /** Keep the native status bar visible after returning from dialogs. */
    @SuppressWarnings("deprecation")
    void showStatusBar() {
        applySystemBarVisibility();
    }

    @SuppressWarnings("deprecation")
    private void applySystemBarVisibility() {
        Window window = activity.getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.show(WindowInsets.Type.statusBars());

                // Keep icon appearance explicit for a light Jet Note surface.
                int appearance = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS;
                if (Build.VERSION.SDK_INT >= 26) {
                    appearance |= WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                }
                controller.setSystemBarsAppearance(appearance, appearance);
            }
            return;
        }

        // Draw edge-to-edge; CSS receives the visible system bar safe area.
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        window.getDecorView().setSystemUiVisibility(flags);
    }

    /**
     * Re-synchronize the cached native safe area with the frontend.
     *
     * WindowInsets can arrive before the dynamically-loaded frontend has defined
     * window.applySystemInsets().  In that case the first JavaScript dispatch is
     * intentionally harmless, but the values must be replayed once the frontend
     * is ready.  requestApplyInsets() also refreshes the cache after system-bar
     * visibility changes.
     */
    void synchronizeInsets() {
        webView.requestApplyInsets();
        if (hasInsets) webView.post(this::dispatchInsets);
    }

    void dispatchInsets() {
        if (!hasInsets) return;
        webView.evaluateJavascript("window.applySystemInsets && window.applySystemInsets("
                + safeTop + "," + safeRight + "," + safeBottom + "," + safeLeft + ","
                + keyboardViewportHeight + "," + keyboardHeight + ")", null);
    }
}
