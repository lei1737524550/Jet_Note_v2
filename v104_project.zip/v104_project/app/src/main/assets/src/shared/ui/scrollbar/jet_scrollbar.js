/* Each route owns its own scrollbar and scroll position. */
(() => {
  const template = document.getElementById('jetScrollbar');
  if (!template) return;
  const routes = [
    ['settingsScreen', '.settings-body'],
    ['postComposeScreen', '.post-compose-body'],
    ['noteViewerScreen', '#noteViewerScroll'],
    ['archiveScreen', '.archive-scroll']
  ];
  const instances = new Map();
  let current = null, queued = false;
  const home = {page:null, target:document.scrollingElement || document.documentElement, bar:template};
  instances.set('home', home);
  function schedule() {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => { queued = false; refresh(); });
  }
  function attach(item) {
    const {bar} = item;
    item.track = bar.querySelector('.jet-scrollbar-track');
    item.thumb = bar.querySelector('.jet-scrollbar-thumb');
    bar.hidden = true;
    let pointer = null;
    item.cancel = () => {
      if (pointer !== null && bar.hasPointerCapture?.(pointer)) bar.releasePointerCapture(pointer);
      pointer = null;
    };
    function move(y) {
      if (current !== item || bar.hidden) { item.cancel(); return; }
      const rect = item.track.getBoundingClientRect();
      const travel = rect.height - item.thumb.offsetHeight;
      const fraction = travel > 0 ? Math.max(0, Math.min(1, (y - rect.top - item.thumb.offsetHeight / 2) / travel)) : 0;
      item.target.scrollTop = fraction * Math.max(0, item.target.scrollHeight - item.target.clientHeight);
      schedule();
    }
    bar.addEventListener('pointerdown', event => {
      refresh();
      if (current !== item || bar.hidden) return;
      pointer = event.pointerId;
      bar.setPointerCapture?.(pointer);
      move(event.clientY);
      event.preventDefault(); event.stopPropagation();
    });
    bar.addEventListener('pointermove', event => {
      if (pointer !== event.pointerId) return;
      move(event.clientY);
      event.preventDefault(); event.stopPropagation();
    });
    for (const name of ['pointerup','pointercancel','lostpointercapture']) bar.addEventListener(name, item.cancel);
    new ResizeObserver(schedule).observe(item.target);
  }
  attach(home);
  function refresh() {
    let selected = home;
    for (const [id, selector] of routes) {
      const page = document.getElementById(id);
      const target = page?.querySelector(selector);
      if (!target) continue;
      if (!instances.has(id)) {
        const bar = template.cloneNode(true);
        bar.removeAttribute('id'); bar.hidden = true; bar.classList.remove('visible');
        page.appendChild(bar);
        const item = {page,target,bar};
        instances.set(id,item); attach(item);
      }
      if (selected === home && page.classList.contains('open')) selected = instances.get(id);
    }
    // Modal/tool routes own interaction; never leave an underlying drag lane active.
    if (document.hidden || document.querySelector('#imageViewer.open, #importPreview.open, .jet-notice-backdrop.open, #deleteConfirmBackdrop.open, #postActionPanel.open')) selected = null;
    if (current !== selected) { current?.cancel(); current = selected; }
    for (const item of instances.values()) {
      const visible = item === selected && item.target.scrollHeight > item.target.clientHeight + 1;
      item.bar.hidden = !visible;
      item.bar.classList.toggle('visible',visible);
      if (!visible) { item.cancel(); continue; }
      const style = getComputedStyle(document.documentElement);
      const safeTop = parseFloat(style.getPropertyValue('--safe-top')) || 0;
      const bottom = parseFloat(style.getPropertyValue('--content-bottom')) || parseFloat(style.getPropertyValue('--safe-bottom')) || 0;
      const header = item.page?.querySelector('.page-action-bar') || document.querySelector('.main-status-bar');
      const top = item.page ? safeTop + (header?.offsetHeight || parseFloat(style.getPropertyValue('--page-action-bar-height')) || 0) : safeTop + (header?.offsetHeight || 0);
      const viewport = window.visualViewport;
      const end = Math.min(window.innerHeight - bottom, (viewport?.offsetTop || 0) + (viewport?.height || window.innerHeight));
      const height = Math.max(0,end - top);
      item.bar.style.top = `${top}px`;
      item.bar.style.height = `${height}px`;
      const thumbHeight = Math.min(height,Math.max(28,height * item.target.clientHeight / item.target.scrollHeight));
      const maxScroll = item.target.scrollHeight - item.target.clientHeight;
      const ratio = Math.max(0,Math.min(1,item.target.scrollTop / maxScroll));
      item.thumb.style.height = `${thumbHeight}px`;
      item.thumb.style.transform = `translateY(${ratio * (height - thumbHeight)}px)`;
    }
  }
  fetch('config.json',{cache:'no-store'}).then(r=>r.ok?r.json():null).then(config=>{
    const width = Number(config?.jet_scrollbar?.visual_width_px);
    const hit = Number(config?.jet_scrollbar?.interaction_width_px);
    const root = document.documentElement.style;
    root.setProperty('--jet-scrollbar-visual-width',`${Number.isFinite(width)&&width>0?width/2:3.5}px`);
    root.setProperty('--jet-scrollbar-interaction-width',`${Number.isFinite(hit)&&hit>0?Math.max(hit,4):20}px`);
    schedule();
  }).catch(()=>{});
  document.addEventListener('scroll',schedule,true);
  document.addEventListener('visibilitychange',schedule);
  window.addEventListener('blur',()=>current?.cancel());
  window.addEventListener('resize',schedule);
  window.visualViewport?.addEventListener('resize',schedule);
  window.addEventListener('jet-note-scrollbar-refresh',schedule);
  new MutationObserver(records=>{
    if (records.some(record=>!record.target.closest?.('.jet-scrollbar'))) schedule();
  }).observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['class','style']});
  window.JetNoteScrollbar = Object.freeze({refresh});
  refresh();
})();
