# Jet Note

当前交付包：v104。统一图标线宽与归档卡片/收藏行为，增加备份进度，修复启动品牌重复。

这是 Android 原生外壳与本地 WebView 界面的笔记项目，包含 Kotlin、Java、JavaScript、HTML 和 CSS。主页、编辑、查看、归档和设置仍由网页模块实现。请以当前源码和文档为准。

工程文档与 `app/` 同级：

- [文档入口](docs/readme.txt)
- [工作规则](docs/readme_before_work.txt)
- [架构说明](docs/architecture.txt)
- [源码定位](docs/codebase.txt)
- [原始问题与修复记录](docs/issues/v100/)
- [方案决策](docs/decisions/)
- [本轮整改记录](docs/issues/v103/v104_changes.txt)

导出名称为 `yyyy-MM-dd_HH-mm-ss.j`，保存到 `Download/Jet Note/`。Android 9 及以下需要通过系统文件夹选择器授权。内部仍使用 ZIP 格式的 Jet Note v2 协议，旧 `.jnote` 可以导入。

静态检查：`node tools/verify.cjs`、`python3 tools/check_assets.py`。
模拟行为测试：`node tools/verify_v101.cjs`、`node tools/verify_v103.cjs`、`node tools/verify_v104.cjs`及`node --test app/tests/*.test.cjs`。
构建：`bash gradlew :app:assembleDebug`，需要本机 Gradle/wrapper、Android SDK 和依赖。当前包没有 wrapper JAR，脚本可以回退已安装的 Gradle。

v104 的静态及模拟行为检查已通过；尚未在当前环境完成 APK 编译、浏览器布局及真机验证。详情见各问题的 resolution 文件。
